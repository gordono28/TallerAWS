#!/bin/bash 
source /home/ec2-user/.bashrc
cd /home/ec2-user/pruebaAWS/ 
nvm use 8.12.0
npm install 